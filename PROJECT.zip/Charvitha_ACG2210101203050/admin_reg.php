<?php
include_once 'connection.php';
$name=$_POST['username'];
$pass=$_POST['password'];

$cmd="insert into admin_user(username,password)values('$name','$pass')";

$sql_status=mysqli_query($conn,$cmd);

if($sql_status){
    echo "Registration is Sucessful";
    echo "<a href='admin_login.html'>Click Here to Login</a>";

}
else{
    echo "Registration Failed..:(";
    echo "<a href='admin_reg.php'>Click Here to Register Again</a>";
}

?>