<?php
include_once 'connection.php';
$uname=$_POST['username'];
$upass=$_POST['password'];
$mobile=$_POST['mobile'];
$address=$_POST['address'];

$cmd="insert into users(username,password,mobile,address)values('$uname','$upass','$mobile','$address')";

$sql_status=mysqli_query($conn,$cmd);

if($sql_status){
    echo "Registration is Sucessful";
    echo "<a href='client_login.html'>Click Here to Login</a>";

}
else{
    echo "Registration Failed..:(";
    echo "Mobile Number Already Registered!!";
    echo "<a href='client_registration.php'>Click Here to Register Again</a>";
}

?>