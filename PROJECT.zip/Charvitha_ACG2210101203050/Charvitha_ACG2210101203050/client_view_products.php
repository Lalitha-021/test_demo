<?php
session_start();
 if(isset($_SESSION['login_status'])){
    if($_SESSION['login_status']=='failed')
    {
        echo "UNAUTHORIZED ATTEMPT...PLEASE LOGIN FIRST";
        echo "<a href='client_login.html'>Click Here to Login</a>";
        die;
    }
 }
 else{
    echo "UNAUTHORIZED ATTEMPT...PLEASE LOGIN FIRST";
    echo "<a href='client_login.html'>Click Here to Login</a>";
    die;

 }
 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>


    <style>
        img
        {
            width:300px;
            height:300px;
        }
        .pdt-card
        {
            width:300px;
            
        }
        .cart-count{
            right:-10px;
            top: -10px;
            background-color:yellow;
            width: 30px;
            height: 30px;
            text-align: center;
            border-radius: 50%;
            font-size: 20px;
        }
    </style>

</head>
<body>
    <div class="d-flex bg-primary w-100 justify-content-around p-2">
    <a href="viewcart.php" class="position-relative">
    <button class="btn btn-danger"><i class="fa fa-2x fa-shopping-cart"></i></button>
    <span class="position-absolute cart-count"><?php $x=count($_SESSION['cart']); echo"$x";   ?></span>
    </a>

    <a href="logout.php">
    <button class="btn btn-warning">LOGOUT</button>
    </a>
    </div>
    
</body>
</html>


<?php

include_once 'connection.php';

$sql_obj=mysqli_query($conn,'select * from products');

$total_rows=mysqli_num_rows($sql_obj);

echo "<div class='row'>";

for($i=0;$i<$total_rows;$i++)
{
    $row=mysqli_fetch_assoc($sql_obj);

    $pid=$row['pid'];
    $name=$row['pname'];
    $price=$row['price'];
    $details=$row['details'];
    $imname=$row['imagename'];

    echo "
        <div class='pdt-card col-xs-12  col-sm-6 col-md-4 text-center border'>
            <div class=' mt-4 m-2 p-2  pb-5 w-75 text-white'>
                <img  src='$imname'>
                <div class='d-flex justify-content-around'>
                <h3 class='text-dark'> $name </h3>
                <h3 class='text-success'>$price</h3>
                </div>
                <div class='text-light bg-secondary'>
                $details
                </div>
                <div>
                <div class='d-flex justify-content-around'>
                <a href='add_to_cart.php?pid=$pid'>
                <button class='btn btn-success'>ADD TO CART</button>
                </a>
                </div>
                </div>
            </div>
        </div>

    ";
}

echo '</div>';


?>