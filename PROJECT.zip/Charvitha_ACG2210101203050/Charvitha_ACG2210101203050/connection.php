<?php
$conn=new mysqli('localhost','root','','e_project');
if($conn->connect_error){
    echo "Connection Error";
    die;

}
?>