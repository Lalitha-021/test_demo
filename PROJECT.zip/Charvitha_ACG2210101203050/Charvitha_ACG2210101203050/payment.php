<?php
include_once 'connection.php';

$name=$_POST['fullname'];
$email=$_POST['email'];
$address=$_POST['address'];
$city=$_POST['city'];
$state=$_POST['state'];
$zipcode=$_POST['zipcode'];
$card_no=$_POST['card_no'];

    $cmd="insert into shipping(full_name,email,address,city,state,zipcode,card_no)values('$name','$email','$address','$city','$state',$zipcode,$card_no)";
    

    mysqli_query($conn,$cmd);

header('location:place_order.php');

?>