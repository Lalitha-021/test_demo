<?php
include_once 'connection.php';
session_start();
$user=$_SESSION['user_details'];

$name=$user['username'];
$id=$user['user_id'];
$mobile=$user['mobile'];
$address=$user['address'];


$cart=$_SESSION['cart'];


for($i=0;$i<count($cart);$i++)
{
    $pid=$cart[$i];
    $cmd="insert into orders(user_name , user_mobile , user_address , user_id , pid) values('$name','$mobile','$address',$id,$pid)";

    mysqli_query($conn,$cmd);

}

echo "<h3> ORDER PLACED SUCCESSFULY!!</h3>";
$_SESSION['cart']=array();
echo "<a href='client_view_products.php'> GO BACK TO VIEW PRODUCTS</a>";







?>