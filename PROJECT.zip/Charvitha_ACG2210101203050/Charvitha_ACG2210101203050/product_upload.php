<?php
include_once 'connection.php';
print_r($_POST);
$name=$_POST['name'];
$price=$_POST['price'];
$details=$_POST['details'];


date_default_timezone_set("Asia/Kolkata");
$unique_file_name=date("Y_m_d_h_i_s").'jpg';
echo "file name=$unique_file_name";

move_uploaded_file($_FILES['pdt_img']['tmp_name'],$unique_file_name);

$cmd="insert into products(pname,price,details,imagename)values('$name',$price,'$details','$unique_file_name')";
echo "SQL query=$cmd";
$sql_status=mysqli_query($conn,$cmd);
if($sql_status){
    echo "Product Uploaded Sucessfully";
    header("location:product_upload_fe.php");
}
else{
    echo "ERror in sql query";
}


?>