<?php
include_once 'connection.php';

$pid=$_GET['pid'];
 mysqli_query($conn,"delete from products where pid=$pid");

 header('location:view_products.php');

?>