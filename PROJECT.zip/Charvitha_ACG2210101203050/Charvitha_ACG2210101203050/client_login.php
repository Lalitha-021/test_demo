<?php
include_once 'connection.php';

session_start();
$_SESSION['cart']=array();

$mobile=$_POST['mobile'];
$password=$_POST['password'];
$cmd="select * from users where mobile='$mobile' and password='$password'";
$sql_obj=mysqli_query($conn,$cmd);
$row_lenght=mysqli_num_rows($sql_obj);


if($row_lenght==0){
    $_SESSION['login_status']='failed';
    echo "<h3>INVALID CREDENTIALS</h3>";
    echo "<a href='client_login.html'>Click Here to Login</a>";
}
else{
    $row=mysqli_fetch_assoc($sql_obj);
    $_SESSION['user_details']=$row;
    
    $_SESSION['login_status']='success';
    header('location:client_view_products.php');
}

?>