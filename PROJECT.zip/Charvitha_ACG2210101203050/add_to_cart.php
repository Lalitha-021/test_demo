<?php
session_start();
$pid=$_GET['pid'];

$tmp_cart=$_SESSION['cart'];

if(!in_array($pid,$tmp_cart)){
    array_push($tmp_cart,$pid);
    print_r($tmp_cart);
    $_SESSION['cart']=$tmp_cart;

}
else{
    echo "Already in the cart";
}
header('location:client_view_products.php');

?>